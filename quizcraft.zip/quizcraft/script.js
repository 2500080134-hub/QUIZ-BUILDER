/**
 * QuizCraft - Interactive Quiz Builder & Examination Platform
 * Complete Vanilla JavaScript Engine (Data, Auth, Admin, User, Quiz & Results)
 */

const QuizCraft = (function () {
  // Storage Keys
  const STORAGE_KEYS = {
    USERS: "quizcraft_users",
    CURRENT_USER: "quizcraft_current_user",
    QUIZZES: "quizcraft_quizzes",
    ATTEMPTS: "quizcraft_attempts",
    SAVED_DRAFTS: "quizcraft_quiz_draft_"
  };

  // Seed Data for Fresh Initialization
  const SEED_USERS = [
    {
      id: "usr_admin_1",
      name: "Admin Director",
      email: "admin@quizcraft.com",
      password: "admin123",
      role: "admin",
      joinedAt: "2026-01-10T09:00:00Z"
    },
    {
      id: "usr_user_1",
      name: "John Doe",
      email: "john@example.com",
      password: "user123",
      role: "user",
      joinedAt: "2026-02-01T10:15:00Z"
    },
    {
      id: "usr_user_2",
      name: "Sarah Connor",
      email: "sarah@example.com",
      password: "user123",
      role: "user",
      joinedAt: "2026-02-14T16:40:00Z"
    }
  ];

  const SEED_QUIZZES = [
    {
      id: "qz_tech_101",
      title: "Full-Stack Web Development Fundamentals",
      category: "Technology",
      difficulty: "Medium",
      description: "Test your understanding of modern frontend, JavaScript semantics, CSS layouts, and web protocols.",
      timeLimitMinutes: 10,
      passPercentage: 70,
      createdAt: "2026-02-10T11:00:00Z",
      createdBy: "Admin Director",
      randomizeQuestions: true,
      questions: [
        {
          id: "q_tech_1",
          type: "mcq",
          question: "Which CSS layout module is primarily designed for one-dimensional layouts along a single axis?",
          options: ["CSS Grid", "Flexbox (Flexible Box Layout)", "Block Flow", "Absolute Positioning"],
          correctAnswer: 1,
          points: 10,
          explanation: "Flexbox is designed for one-dimensional layouts (row or column), whereas CSS Grid is two-dimensional."
        },
        {
          id: "q_tech_2",
          type: "tf",
          question: "JavaScript is a statically-typed compiled language.",
          options: ["True", "False"],
          correctAnswer: "False",
          points: 10,
          explanation: "JavaScript is dynamically typed and traditionally interpreted or JIT-compiled at runtime."
        },
        {
          id: "q_tech_3",
          type: "mcq",
          question: "What does the HTTP 404 status code indicate?",
          options: ["Internal Server Error", "Unauthorized Access", "Resource Not Found", "Bad Request"],
          correctAnswer: 2,
          points: 10,
          explanation: "HTTP 404 Not Found indicates that the origin server did not find a current representation for the target resource."
        },
        {
          id: "q_tech_4",
          type: "open",
          question: "What standard browser Web Storage object persists data with no expiration time even after browser restart?",
          acceptedAnswers: ["localStorage", "local storage", "window.localStorage"],
          points: 15,
          explanation: "The localStorage mechanism stores data with no expiration date, unlike sessionStorage."
        },
        {
          id: "q_tech_5",
          type: "mcq",
          question: "In JavaScript, which array method creates a new array with all elements that pass the test implemented by the provided function?",
          options: ["map()", "filter()", "reduce()", "forEach()"],
          correctAnswer: 1,
          points: 10,
          explanation: "Array.prototype.filter() returns a shallow copy of a portion of a given array, filtered down to just the elements that pass the test."
        }
      ]
    },
    {
      id: "qz_hist_202",
      title: "World History: Ancient Civilizations & Revolutions",
      category: "History",
      difficulty: "Easy",
      description: "Explore pivotal epochs from the Nile Valley to the Industrial Revolution in this foundational history challenge.",
      timeLimitMinutes: 8,
      passPercentage: 60,
      createdAt: "2026-02-12T14:30:00Z",
      createdBy: "Admin Director",
      randomizeQuestions: false,
      questions: [
        {
          id: "q_hist_1",
          type: "mcq",
          question: "Which river is famously recognized as the lifeblood of ancient Egyptian civilization?",
          options: ["Amazon River", "Nile River", "Euphrates River", "Danube River"],
          correctAnswer: 1,
          points: 10,
          explanation: "The Nile River provided fertile soil, transportation, and water, shaping ancient Egyptian agriculture and society."
        },
        {
          id: "q_hist_2",
          type: "tf",
          question: "The Magna Carta was signed in the year 1215 in England.",
          options: ["True", "False"],
          correctAnswer: "True",
          points: 10,
          explanation: "King John of England granted the Magna Carta at Runnymede in June 1215."
        },
        {
          id: "q_hist_3",
          type: "open",
          question: "In which European country did the Industrial Revolution originate during the 18th century?",
          acceptedAnswers: ["Great Britain", "Britain", "England", "United Kingdom", "UK"],
          points: 15,
          explanation: "The Industrial Revolution began in Great Britain due to abundant coal, iron, and economic factors."
        },
        {
          id: "q_hist_4",
          type: "mcq",
          question: "Who was the first elected President of the United States?",
          options: ["Thomas Jefferson", "Alexander Hamilton", "George Washington", "John Adams"],
          correctAnswer: 2,
          points: 10,
          explanation: "George Washington served as the first U.S. President from 1789 to 1797."
        }
      ]
    },
    {
      id: "qz_sci_303",
      title: "Space Exploration & Astrophysics",
      category: "Science",
      difficulty: "Hard",
      description: "Test your cosmic acumen on planetary mechanics, stellar evolution, and historic lunar missions.",
      timeLimitMinutes: 12,
      passPercentage: 75,
      createdAt: "2026-02-15T09:45:00Z",
      createdBy: "Admin Director",
      randomizeQuestions: true,
      questions: [
        {
          id: "q_sci_1",
          type: "mcq",
          question: "What is the boundary surrounding a black hole beyond which no light or matter can escape called?",
          options: ["Photon Sphere", "Accretion Disk", "Event Horizon", "Schwarzschild Singularity"],
          correctAnswer: 2,
          points: 15,
          explanation: "The Event Horizon is the boundary where the escape velocity equals the speed of light."
        },
        {
          id: "q_sci_2",
          type: "tf",
          question: "Venus rotates in the opposite direction (retrograde) compared to most other planets in our solar system.",
          options: ["True", "False"],
          correctAnswer: "True",
          points: 10,
          explanation: "Venus has a clockwise retrograde rotation, meaning the Sun rises in the west and sets in the east."
        },
        {
          id: "q_sci_3",
          type: "open",
          question: "What was the name of the Apollo mission that first landed humans on the Moon in July 1969?",
          acceptedAnswers: ["Apollo 11", "Apollo-11", "Apollo11"],
          points: 15,
          explanation: "Apollo 11 carried Neil Armstrong, Buzz Aldrin, and Michael Collins to the Moon in July 1969."
        },
        {
          id: "q_sci_4",
          type: "mcq",
          question: "Which elemental gas is the most abundant by mass in the universe?",
          options: ["Helium", "Hydrogen", "Oxygen", "Nitrogen"],
          correctAnswer: 1,
          points: 10,
          explanation: "Hydrogen accounts for roughly 74% of the baryonic mass of the known universe."
        }
      ]
    },
    {
      id: "qz_biz_404",
      title: "Modern Business & Startup Strategy",
      category: "Business",
      difficulty: "Medium",
      description: "Sharpen your knowledge of venture capital, agile frameworks, unit economics, and product market fit.",
      timeLimitMinutes: 10,
      passPercentage: 70,
      createdAt: "2026-02-18T16:00:00Z",
      createdBy: "Admin Director",
      randomizeQuestions: false,
      questions: [
        {
          id: "q_biz_1",
          type: "mcq",
          question: "What does the startup acronym MVP stand for?",
          options: ["Most Valuable Partner", "Minimum Viable Product", "Maximum Value Pricing", "Market Validation Protocol"],
          correctAnswer: 1,
          points: 10,
          explanation: "Minimum Viable Product is a version with just enough features to be usable by early customers."
        },
        {
          id: "q_biz_2",
          type: "tf",
          question: "Customer Acquisition Cost (CAC) should ideally exceed Customer Lifetime Value (LTV) for a healthy business.",
          options: ["True", "False"],
          correctAnswer: "False",
          points: 10,
          explanation: "LTV must be significantly higher than CAC (typically 3:1 or better) to maintain profitable unit economics."
        },
        {
          id: "q_biz_3",
          type: "open",
          question: "In Scrum and Agile software development, what is a time-boxed iteration (typically 1 to 4 weeks) called?",
          acceptedAnswers: ["sprint", "iteration", "sprint cycle"],
          points: 15,
          explanation: "A Sprint is a repeatable time-box during which a 'Done' increment of product is created."
        },
        {
          id: "q_biz_4",
          type: "mcq",
          question: "What term describes a privately held startup company valued at over $1 billion?",
          options: ["Centaur", "Decacorn", "Unicorn", "Blue Chip"],
          correctAnswer: 2,
          points: 10,
          explanation: "The term 'Unicorn' was popularized by venture capitalist Aileen Lee in 2013 for \$1B+ startups."
        }
      ]
    }
  ];

  const SEED_ATTEMPTS = [
    {
      id: "att_init_1",
      quizId: "qz_tech_101",
      quizTitle: "Full-Stack Web Development Fundamentals",
      userId: "usr_user_1",
      userName: "John Doe",
      userEmail: "john@example.com",
      startedAt: "2026-02-20T10:00:00Z",
      completedAt: "2026-02-20T10:07:30Z",
      timeSpentSeconds: 450,
      totalQuestions: 5,
      correctCount: 4,
      score: 45,
      maxScore: 55,
      percentage: 82,
      passed: true,
      answers: {
        "q_tech_1": { answer: 1, isCorrect: true, earnedPoints: 10 },
        "q_tech_2": { answer: "False", isCorrect: true, earnedPoints: 10 },
        "q_tech_3": { answer: 2, isCorrect: true, earnedPoints: 10 },
        "q_tech_4": { answer: "localStorage", isCorrect: true, earnedPoints: 15 },
        "q_tech_5": { answer: 0, isCorrect: false, earnedPoints: 0 }
      }
    },
    {
      id: "att_init_2",
      quizId: "qz_hist_202",
      quizTitle: "World History: Ancient Civilizations & Revolutions",
      userId: "usr_user_2",
      userName: "Sarah Connor",
      userEmail: "sarah@example.com",
      startedAt: "2026-02-22T14:10:00Z",
      completedAt: "2026-02-22T14:15:45Z",
      timeSpentSeconds: 345,
      totalQuestions: 4,
      correctCount: 4,
      score: 45,
      maxScore: 45,
      percentage: 100,
      passed: true,
      answers: {
        "q_hist_1": { answer: 1, isCorrect: true, earnedPoints: 10 },
        "q_hist_2": { answer: "True", isCorrect: true, earnedPoints: 10 },
        "q_hist_3": { answer: "Britain", isCorrect: true, earnedPoints: 15 },
        "q_hist_4": { answer: 2, isCorrect: true, earnedPoints: 10 }
      }
    },
    {
      id: "att_init_3",
      quizId: "qz_biz_404",
      quizTitle: "Modern Business & Startup Strategy",
      userId: "usr_user_1",
      userName: "John Doe",
      userEmail: "john@example.com",
      startedAt: "2026-02-24T18:00:00Z",
      completedAt: "2026-02-24T18:08:20Z",
      timeSpentSeconds: 500,
      totalQuestions: 4,
      correctCount: 3,
      score: 35,
      maxScore: 45,
      percentage: 78,
      passed: true,
      answers: {
        "q_biz_1": { answer: 1, isCorrect: true, earnedPoints: 10 },
        "q_biz_2": { answer: "False", isCorrect: true, earnedPoints: 10 },
        "q_biz_3": { answer: "sprint", isCorrect: true, earnedPoints: 15 },
        "q_biz_4": { answer: 1, isCorrect: false, earnedPoints: 0 }
      }
    }
  ];

  // Helper Functions
  function getItem(key, defaultValue = null) {
    try {
      const data = localStorage.getItem(key);
      return data ? JSON.parse(data) : defaultValue;
    } catch (e) {
      console.error(`Error reading ${key} from localStorage:`, e);
      return defaultValue;
    }
  }

  function setItem(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error(`Error writing ${key} to localStorage:`, e);
      return false;
    }
  }

  // Initialize Seed Data
  function initStore() {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
      setItem(STORAGE_KEYS.USERS, SEED_USERS);
    }
    if (!localStorage.getItem(STORAGE_KEYS.QUIZZES)) {
      setItem(STORAGE_KEYS.QUIZZES, SEED_QUIZZES);
    }
    if (!localStorage.getItem(STORAGE_KEYS.ATTEMPTS)) {
      setItem(STORAGE_KEYS.ATTEMPTS, SEED_ATTEMPTS);
    }
  }

  function resetSampleData() {
    setItem(STORAGE_KEYS.USERS, SEED_USERS);
    setItem(STORAGE_KEYS.QUIZZES, SEED_QUIZZES);
    setItem(STORAGE_KEYS.ATTEMPTS, SEED_ATTEMPTS);
    showToast("Application restored to original sample data!", "success");
    setTimeout(() => window.location.reload(), 1000);
  }

  // Toast Notification
  function showToast(message, type = "info") {
    let container = document.getElementById("toast-container");
    if (!container) {
      container = document.createElement("div");
      container.id = "toast-container";
      document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast toast-${type}`;

    let iconSvg = "";
    if (type === "success") {
      iconSvg = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>`;
    } else if (type === "error") {
      iconSvg = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>`;
    } else if (type === "warning") {
      iconSvg = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"></path><line x1="12" y1="9" x2="12" y2="13"></line><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>`;
    } else {
      iconSvg = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>`;
    }

    toast.innerHTML = `${iconSvg}<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(20px)";
      setTimeout(() => toast.remove(), 300);
    }, 3500);
  }

  // Authentication & Session Guard
  function getCurrentUser() {
    return getItem(STORAGE_KEYS.CURRENT_USER, null);
  }

  function setCurrentUser(user) {
    if (user) {
      setItem(STORAGE_KEYS.CURRENT_USER, user);
    } else {
      localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
  }

  function getUsers() {
    return getItem(STORAGE_KEYS.USERS, []);
  }

  function signup(name, email, password, role = "user") {
    if (!name || !email || !password) {
      showToast("Please fill in all required fields.", "error");
      return false;
    }

    const cleanEmail = email.trim().toLowerCase();
    const users = getUsers();

    if (users.some((u) => u.email.toLowerCase() === cleanEmail)) {
      showToast("An account with this email already exists. Please sign in.", "error");
      return false;
    }

    const newUser = {
      id: "usr_" + Date.now().toString(36) + Math.random().toString(36).substring(2, 5),
      name: name.trim(),
      email: cleanEmail,
      password: password,
      role: role === "admin" ? "admin" : "user",
      joinedAt: new Date().toISOString()
    };

    users.push(newUser);
    setItem(STORAGE_KEYS.USERS, users);
    setCurrentUser(newUser);

    showToast(`Account created successfully! Welcome, ${newUser.name}.`, "success");
    setTimeout(() => {
      window.location.href = newUser.role === "admin" ? "admin.html" : "user.html";
    }, 700);

    return true;
  }

  function login(email, password) {
    if (!email || !password) {
      showToast("Please provide both email and password.", "error");
      return false;
    }

    const cleanEmail = email.trim().toLowerCase();
    const users = getUsers();
    const matchedUser = users.find(
      (u) => u.email.toLowerCase() === cleanEmail && u.password === password
    );

    if (!matchedUser) {
      showToast("Invalid email or password. Please try again.", "error");
      return false;
    }

    setCurrentUser(matchedUser);
    showToast(`Signed in successfully! Welcome back, ${matchedUser.name}.`, "success");

    setTimeout(() => {
      window.location.href = matchedUser.role === "admin" ? "admin.html" : "user.html";
    }, 700);

    return true;
  }

  function demoLogin(role) {
    if (role === "admin") {
      login("admin@quizcraft.com", "admin123");
    } else {
      login("john@example.com", "user123");
    }
  }

  function logout() {
    setCurrentUser(null);
    showToast("You have been signed out.", "info");
    setTimeout(() => {
      window.location.href = "index.html";
    }, 600);
  }

  function requireAuth(expectedRole = null) {
    const user = getCurrentUser();
    if (!user) {
      window.location.href = "index.html?reason=unauthenticated";
      return null;
    }

    if (expectedRole && user.role !== expectedRole) {
      if (user.role === "admin") {
        window.location.href = "admin.html";
      } else {
        window.location.href = "user.html";
      }
      return null;
    }

    return user;
  }

  // Quizzes CRUD
  function getQuizzes() {
    return getItem(STORAGE_KEYS.QUIZZES, []);
  }

  function getQuizById(id) {
    const quizzes = getQuizzes();
    return quizzes.find((q) => q.id === id) || null;
  }

  function saveQuiz(quizData) {
    const quizzes = getQuizzes();
    const existingIndex = quizzes.findIndex((q) => q.id === quizData.id);

    if (existingIndex >= 0) {
      quizzes[existingIndex] = quizData;
    } else {
      quizzes.unshift(quizData);
    }

    setItem(STORAGE_KEYS.QUIZZES, quizzes);
    return true;
  }

  function deleteQuiz(id) {
    let quizzes = getQuizzes();
    quizzes = quizzes.filter((q) => q.id !== id);
    setItem(STORAGE_KEYS.QUIZZES, quizzes);
    return true;
  }

  // Attempts CRUD
  function getAttempts() {
    return getItem(STORAGE_KEYS.ATTEMPTS, []);
  }

  function getAttemptById(id) {
    const attempts = getAttempts();
    return attempts.find((a) => a.id === id) || null;
  }

  function saveAttempt(attempt) {
    const attempts = getAttempts();
    attempts.unshift(attempt);
    setItem(STORAGE_KEYS.ATTEMPTS, attempts);
    return attempt;
  }

  // Auto-Scoring Algorithm for MCQ, True/False, and Open-ended
  function gradeQuizSubmission(quiz, userAnswers) {
    let score = 0;
    let maxScore = 0;
    let correctCount = 0;
    const gradedAnswers = {};

    quiz.questions.forEach((q) => {
      const qPoints = Number(q.points) || 10;
      maxScore += qPoints;
      const givenAns = userAnswers[q.id];

      let isCorrect = false;

      if (q.type === "mcq") {
        // Compare option index
        if (givenAns !== undefined && Number(givenAns) === Number(q.correctAnswer)) {
          isCorrect = true;
        }
      } else if (q.type === "tf") {
        // Compare boolean string ("True" or "False")
        if (givenAns && givenAns.toString().toLowerCase() === q.correctAnswer.toString().toLowerCase()) {
          isCorrect = true;
        }
      } else if (q.type === "open") {
        // Fuzzy comparison against accepted keywords
        if (givenAns && typeof givenAns === "string") {
          const cleanGiven = givenAns.trim().toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "");
          const accepted = (q.acceptedAnswers || []).map((ans) =>
            ans.trim().toLowerCase().replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g, "")
          );

          // Check direct match or substring presence
          isCorrect = accepted.some((acc) => cleanGiven === acc || cleanGiven.includes(acc) || acc.includes(cleanGiven));
        }
      }

      if (isCorrect) {
        score += qPoints;
        correctCount++;
      }

      gradedAnswers[q.id] = {
        answer: givenAns !== undefined ? givenAns : null,
        isCorrect: isCorrect,
        earnedPoints: isCorrect ? qPoints : 0,
        maxPoints: qPoints
      };
    });

    const percentage = maxScore > 0 ? Math.round((score / maxScore) * 100) : 0;
    const passThreshold = Number(quiz.passPercentage) || 70;
    const passed = percentage >= passThreshold;

    return {
      score,
      maxScore,
      correctCount,
      percentage,
      passed,
      gradedAnswers
    };
  }

  // Fisher-Yates Shuffle
  function shuffleArray(arr) {
    const copy = [...arr];
    for (let i = copy.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [copy[i], copy[j]] = [copy[j], copy[i]];
    }
    return copy;
  }

  // Format Helper
  function formatDuration(seconds) {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs < 10 ? "0" : ""}${secs}s`;
  }

  function formatDate(isoString) {
    if (!isoString) return "N/A";
    const date = new Date(isoString);
    return date.toLocaleDateString(undefined, {
      month: "short",
      day: "numeric",
      year: "numeric"
    });
  }

  // UI Setup & Bindings
  function setupUserDisplay(user) {
    if (!user) return;
    const nameEls = document.querySelectorAll(".current-user-name");
    const roleEls = document.querySelectorAll(".current-user-role");
    const avatarEls = document.querySelectorAll(".current-user-avatar");

    nameEls.forEach((el) => (el.textContent = user.name));
    roleEls.forEach((el) => (el.textContent = user.role.toUpperCase()));

    const initials = user.name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .substring(0, 2);

    avatarEls.forEach((el) => {
      el.textContent = initials || "U";
    });

    // Hook up logout buttons
    document.querySelectorAll(".logout-trigger").forEach((btn) => {
      btn.onclick = (e) => {
        e.preventDefault();
        logout();
      };
    });

    // Mobile sidebar toggle
    const toggleBtn = document.getElementById("sidebar-toggle-btn");
    const sidebar = document.querySelector(".app-sidebar");
    const backdrop = document.getElementById("sidebar-backdrop");

    if (toggleBtn && sidebar) {
      toggleBtn.onclick = () => {
        sidebar.classList.toggle("open");
        if (backdrop) backdrop.classList.toggle("active");
      };
    }

    if (backdrop && sidebar) {
      backdrop.onclick = () => {
        sidebar.classList.remove("open");
        backdrop.classList.remove("active");
      };
    }
  }

  // Initialize store immediately
  initStore();

  // Public API
  return {
    STORAGE_KEYS,
    initStore,
    resetSampleData,
    showToast,
    getCurrentUser,
    setCurrentUser,
    getUsers,
    signup,
    login,
    demoLogin,
    logout,
    requireAuth,
    getQuizzes,
    getQuizById,
    saveQuiz,
    deleteQuiz,
    getAttempts,
    getAttemptById,
    saveAttempt,
    gradeQuizSubmission,
    shuffleArray,
    formatDuration,
    formatDate,
    setupUserDisplay
  };
})();
